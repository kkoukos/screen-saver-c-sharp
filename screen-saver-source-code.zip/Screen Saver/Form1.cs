﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Screen_Saver
{
    public partial class Form1 : Form
    {
        int balls = 0;
        string temps;
        int tempi;
        public Form1()
        {


            
            InitializeComponent();



        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {   
            if(numb.Text != "")
            {
            tempi = Convert.ToInt16(numb.Text);
            }
           
            
            if(tempi < 0)
            {
                error.Text = "INSERT A POSITIVE NUMBER";
            }
            else if( tempi == 0)
            {
                error.Text = "ADD MORE THAN 0 BALLS";
            }
            else if(tempi > 20)
            {
                error.Text = "TOO MANY BALLS (<=20)";
            }
            else
            {
                balls=tempi;
                error.Visible = false;
                button1.Visible = false;
                numb.Visible = false;
                text1.Visible = false;
                BackColor = Color.Blue;
                TransparencyKey = Color.Blue;
                WindowState = FormWindowState.Maximized;
                FormBorderStyle = FormBorderStyle.None;

                PictureBox Ball = new PictureBox();
                Ball.
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            error.Text = " ";
        }
    }
}
